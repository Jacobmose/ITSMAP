package com.leafcastlelabs.thearnieexercisefinder;

import android.content.Intent;
import android.graphics.PorterDuff;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.app.ActionBarActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;


public class MainActivity extends ActionBarActivity {

    private static final long MIN_TIME_BETWEEN_LOCATION_UPDATES = 5 * 1000;    // milisecs
    private static final float MIN_DISTANCE_MOVED_BETWEEN_LOCATION_UPDATES = 1;  // meter
    public static final String EXTRA_USER_LATITUDE = "location_latitude";
    public static final String EXTRA_USER_LONGITUDE = "location_longitude";

    private Button btnExit;
    private Button btnTracking;
    private Button btnMap;
    private TextView txtPosition;
    private TextView txtStatus;

    private boolean isTracking = false;
    private LocationManager locationManager;
    private Location userLocation;
    private double latitude, longitude;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnExit = (Button)findViewById(R.id.btnExit);
        btnExit.getBackground().setColorFilter(0xDDDDDD00, PorterDuff.Mode.MULTIPLY);
        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        btnTracking = (Button)findViewById(R.id.btnToggleTracking);
        btnTracking.getBackground().setColorFilter(0xDDDDDD00, PorterDuff.Mode.MULTIPLY);
        btnTracking.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toogleTracking();
            }
        });
        btnMap = (Button)findViewById(R.id.btnMap);
        btnMap.getBackground().setColorFilter(0xDDDDDD00, PorterDuff.Mode.MULTIPLY);
        btnMap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent mapIntent = new Intent(getApplicationContext(), MapsActivity.class);
                if(userLocation!=null) {
                    //if location known, send it to the map activity
                    mapIntent.putExtra(EXTRA_USER_LATITUDE, userLocation.getLatitude());
                    mapIntent.putExtra(EXTRA_USER_LONGITUDE, userLocation.getLongitude());
                }
                startActivity(mapIntent);

            }
        });
        txtPosition = (TextView)findViewById(R.id.txtCurrentLocation);
        txtStatus = (TextView)findViewById(R.id.txtStatus);

        updateStatus();
    }

    private void toogleTracking(){

        if(isTracking){
            stopTracking();
        } else {
            startTracking();
        }
        updateStatus();
    }

    private boolean startTracking(){

        try {
            if (locationManager == null) {
                locationManager = (LocationManager) getSystemService(LOCATION_SERVICE);
            }

            long minTime = MIN_TIME_BETWEEN_LOCATION_UPDATES;
            float minDistance = MIN_DISTANCE_MOVED_BETWEEN_LOCATION_UPDATES;
            Criteria criteria = new Criteria();
            criteria.setAccuracy(Criteria.ACCURACY_FINE);
            criteria.setPowerRequirement(Criteria.POWER_MEDIUM);

            if (locationManager != null) {

                //locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, minTime, minDistance, locationListener);         //for specifying GPS provider
                //locationManager.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, minTime, minDistance, locationListener);     //for specifying Network provider
                locationManager.requestLocationUpdates(minTime, minDistance, criteria, locationListener, null);                         //Use criteria to chose best provider
            } else {
                return false;
            }
            isTracking = true;
            return true;
        } catch (Exception ex) {
            //things can go wrong
            Log.e("TRACKER", "Error during start", ex);
            return false;
        }
    }

    private boolean stopTracking(){
        try {
            locationManager.removeUpdates(locationListener);
            isTracking = false;
            return true;
        } catch (Exception ex) {
            //things can go wrong here as well (listener is null)
            Log.e("TRACKER", "Error during stop", ex);
            return false;
        }
    }

    private void updateStatus(){
        String status = "";
        if(userLocation!=null){
            status += " location=known";
            latitude = userLocation.getLatitude();
            longitude = userLocation.getLongitude();
            txtPosition.setText("Lat: \t" + latitude + "\nLong: \t" + longitude);
        } else {
            txtPosition.setText("Unknown\n");
            status += " location=unknown";

        }

        if(isTracking){
            status += " tracking=true";
        } else {
            status += " tracking=false";
        }

        if(userLocation==null && locationManager!=null) {
            Location lastGps = locationManager.getLastKnownLocation(LocationManager.GPS_PROVIDER);
            Location lastNetwork = locationManager.getLastKnownLocation(LocationManager.NETWORK_PROVIDER);
            status += " \nlast_known_location=";
            if(lastGps!=null){
                status += "{" + lastGps.getLatitude() + ";" + lastGps.getLongitude() + "}(GPS) ";
            }
            if(lastNetwork!=null){
                status += "{" + lastNetwork.getLatitude() + ";" + lastNetwork.getLongitude() + "}(Network) ";
            }
        }

        txtStatus.setText("Status:" + status);
    }

    private void broadcastLocationUpdate(Location location){

        Intent update = new Intent("LOCATION_UPDATE");
        update.putExtra(EXTRA_USER_LATITUDE, location.getLatitude());
        update.putExtra(EXTRA_USER_LONGITUDE, location.getLongitude());
        LocalBroadcastManager.getInstance(this).sendBroadcast(update);

    }

    private LocationListener locationListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location location) {

            userLocation = location;
            updateStatus();
            broadcastLocationUpdate(location);
        }

        @Override
        public void onStatusChanged(String provider, int status, Bundle extras) {

        }

        @Override
        public void onProviderEnabled(String provider) {

        }

        @Override
        public void onProviderDisabled(String provider) {

        }
    };
}

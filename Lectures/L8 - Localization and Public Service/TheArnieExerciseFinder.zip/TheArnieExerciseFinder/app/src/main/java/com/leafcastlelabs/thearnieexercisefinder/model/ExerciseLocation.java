package com.leafcastlelabs.thearnieexercisefinder.model;

/**
 * Created by kasper on 06/05/15.
 */
public class ExerciseLocation {

    private double latitude;
    private double longitude;
    private String name;
    private String description;

    public ExerciseLocation(double lati, double longi, String nam, String desc){
        latitude = lati;
        longitude = longi;
        name = nam;
        description = desc;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }
}
